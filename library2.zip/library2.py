class LibraryItem:
    def __init__(self, item_id, title):
        self.item_id = item_id
        self.title = title

class Book(LibraryItem):
    def __init__(self, item_id, title, author):
        super().__init__(item_id, title)
        self.author = author
        self.available_copies = 0

    def borrow_book(self):
        if self.available_copies > 0:
            self.available_copies -= 1
            print("Book borrowed successfully.")
        else:
            print("Book not available.")

    def return_book(self):
        self.available_copies += 1
        print("Book returned successfully.")

class Member:
    def __init__(self, member_id, name):
        self.member_id = member_id
        self.name = name
        self.borrowed_books = []

    def borrow_book(self, book):
        if book.available_copies > 0:
            self.borrowed_books.append(book)
            book.borrow_book()
            print(f"{self.name} borrowed {book.title}.")
        else:
            print("Book not available.")

    def return_book(self, book):
        if book in self.borrowed_books:
            self.borrowed_books.remove(book)
            book.return_book()
            print(f"{self.name} returned {book.title}.")
        else:
            print("You haven't borrowed this book.")

class Library:
    def __init__(self):
        self.books = []
        self.members = []

    def add_item(self, item):
        self.books.append(item)

    def add_member(self, member):
        self.members.append(member)

# Example usage:
library = Library()
book1 = Book("B001", "The Lord of the Rings", "J.R.R. Tolkien")
library.add_item(book1)

member1 = Member("M001", "Alice")
library.add_member(member1)

member1.borrow_book(book1)